=== CBX Office Opening & Business Hours ===
Contributors: codeboxr, manchumahara
Tags: business, time, office, opening hour, business hour, open, close, holiday
Requires at least: 3.0.1
Tested up to: 5.1.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Office opening and close time or business hours display

== Description ==

This plugin helps to display any office or commercial entitity's business hours or office opening/close hours in tabular or compact form in various
ways.

The business hours can be displayed in

- Frontend Widget
- Shortcode
- Dashboard Widget with role manager
- Custom function to call in theme or other plugin to display in custom way


Shortcode Format:

[cbxbusinesshours]
[cbxbusinesshours compact="0/1"]  where compact = 0 regular table display, compact = 1  if multiple days have same opening and closing time will display in group

== Installation ==

WordPress plugin dir has a very good article about how to install or manage plugin install which is best and we suggest to [follow that](https://codex.wordpress.org/Managing_Plugins#Installing_Plugins)
This plugin can be install like any other wordpress plugin.



== Screenshots ==

1. None now


== Changelog ==

= 1.0.0 =
* Initial relesae

